
struct event_object;

#define EV_COMMON struct event_object *event;

#include "libev/ev.h"